"use strict";
(function(f){
var insert_ins = function insert_ins(ins, selector, where, one){
if (typeof ins == 'object' && ins.innerHTML !== undefined) ins = ins.outherHTML;
if (ins == undefined) return;
if (one == undefined) one = false;
if (typeof selector == 'string') {(one==false) ? selector = document.querySelectorAll(selector) : selector = [document.querySelector(selector)];} else if(!one) {selector = selector[0];}
var locate = {beforeend:1,beforebegin:1,afterend:1,afterbegin:1};
if (locate[where] === undefined) where = 'beforeend';
if (selector.length<1 || selector[0]==null) return;
for (var i=0; i<selector.length; i++){
	selector[i].insertAdjacentHTML(where,ins);
}
return 1;}
var load_adsbygoogle = function (selector){
if (typeof selector == undefined) selector = 'ins.adsbygoogle';
	[].forEach.call(document.querySelectorAll('ins.adsbygoogle'),function(e,i){if(e.innerHTML==='') (adsbygoogle = f.adsbygoogle || []).push({});});
};
var load_adsbygoogle_sc = function(){
(function(f,e,n,k,i){if(!e.getElementById('adsbygoogle')){var n=e.createElement(n),y=e.getElementsByTagName(i)[0];n.setAttribute('id','adsbygoogle');n.async=1;n.src=k;y.appendChild(n);if(typeof(Adds) == 'undefined'){n.onload = function() {}}}})(window,document,'script','//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js','head');
}
// var unload_adsbygoogle_sc = function(){
// 	var a = document.getElementById('adsbygoogle');
// 	if (a !== undefined) a.remove();
// }
var fill_slot = function(slots,slot){
	/*console.log(e.getAttribute('data-ad-slot'));*/slot.setAttribute('data-ad-slot',slots[Math.floor(Math.random()*slots.length)]);slot.setAttribute('data-adsbygoogle-status','');/*console.log(e.getAttribute('data-ad-slot'));*/
}
var fill_empty_slots = function (alt_slot){
[].forEach.call(document.querySelectorAll('ins.adsbygoogle'),function(e,i){
	if(e.innerHTML==='') {
		if (alt_slot === undefined) {e.innerHTML="";e.setAttribute('data-adsbygoogle-status','');}
		else if (alt_slot.length>0) {fenki.fill_slot(alt_slot,e)}
		else {e.setAttribute('data-ad-slot',alt_slot);}
		}
});
};
var change_slots = function (alt_slot){[].forEach.call(document.querySelectorAll('ins.adsbygoogle'),function(e,i){fill_slot(alt_slot,e);e.innerHTML="";})};
window.fenki = {insert_ins:insert_ins,load_adsbygoogle:load_adsbygoogle,fill_empty_slots:fill_empty_slots,change_slots:change_slots,fill_slot:fill_slot,load_adsbygoogle_sc:load_adsbygoogle_sc};
setTimeout(function(){fenki.load_adsbygoogle_sc();},100);
setTimeout(function(){fenki.load_adsbygoogle();},1000);
})(window);
fenki.slots = [4669084906,9474843709,5713669301,7190402508,3678532908,2620602100,8667135700,5155266102,4250282503,9099284506,8680482109,8820082901];
var b='<ins class="adsbygoogle" style="display:inline-block;float:left;width:320px;height:50px" data-ad-client="ca-pub-3624498980441810" data-ad-slot="'+fenki.slots[Math.floor(Math.random()*fenki.slots.length)]+'" data-ad-format="auto"></ins>';
fenki.insert_ins(b,'#branding','beforeend',1);
var b = '<ins class="adsbygoogle" style="display:inline-block;width:485px;height:60px" data-ad-client="ca-pub-3624498980441810" data-ad-slot="'+fenki.slots[Math.floor(Math.random()*fenki.slots.length)]+'" data-ad-format="auto"></ins>';
fenki.insert_ins(b,'.wrap_l','beforeend',0);fenki.insert_ins(b,'.wrap_l','beforeend',0);
setTimeout(function(){
fenki.fill_empty_slots(fenki.slots);
fenki.load_adsbygoogle();
},6000);
setInterval(function(){
fenki.change_slots(fenki.slots);
fenki.load_adsbygoogle();
},30000);