(function(w){var t = setInterval(function(){
var $ = w.jQuery;
if ($){
clearInterval(t);
     jQuery.extend(jQuery.fn, {
    compactLabel: function() {
      var form = jQuery(this);
      var inputs = form.find('input:text, input:password, input[type=email], input[type=number], textarea');
      inputs.each(function(){
        var field = jQuery(this);
        var show = jQuery(this).val() ? false : true;
        var label = field.prev();//form.find('label[for="' + field.attr('id') + '"]');
        jQuery(this).parents('.form-item:first').addClass('compact-label-wrap');
       if(label.hasClass('compact-label')) { // только с этим классом скрываем поле
            if(!show) label.hide();
            else label.show();
            label.addClass('compact-label');
            field.focus(function(){
                label.fadeOut(200);
            });
            field.blur(function(){
                if(!field.val())
                    label.fadeIn(200);
            });
       }
      });
    }
  });
      $('form').compactLabel();

	$(document).ready(function() {
    
        // $('.pp_region .webform-confirmation').livequery(function(){
        //     $(this).parents('.block-webform').addClass('block_confirm');
        // });
        
        $('.ico_close_ims').on('click,touchstart',function(){
            $('.pp_fon').hide();
            $('#block-views-task-block-1 .views-field-field-photo-2').hide();
        });
        $('.pp_fon').on('click,touchstart',function(){
            $('.pp_fon').hide();
            $('#block-views-task-block-1 .views-field-field-photo-2').hide();
            $('.pp_region .block-webform').hide();
        });
        // $('.pp_region .block-webform span.close').livequery(function(){
        //     $(this).on('click,touchstart',function(){
        //         $('.pp_fon').hide();
        //         $('.pp_region .block-webform').hide();
        //     });
        // });
        // $('.pp_region .block-webform span.close').on('click,touchstart',function(){
            // $('.pp_fon').hide();
            // $('.pp_region .block-webform').hide();
        // });
        // $('#block-block-3 .btn').on('click,touchstart',function(){
        //     $('.pp_region .pp_fon').show();
        //     $('.pp_region .block-webform#block-webform-client-block-21').show();
        // });
        $('#block-views-task-block-1 .views-field-field-photo-1 span.show_m, #block-views-task-block-1 .views-field-field-photo img').on('click,touchstart',function(){
            $(this).parents('.views-row').find('.pp_fon').show();
            $(this).parents('.views-row').find('.views-field-field-photo-2').show();
        });

        // $('#block-block-16 .btn').on('click,touchstart',function(){
        //     $('.pp_region .pp_fon').show();
        //     $('.pp_region .block-webform#block-webform-client-block-20').show();
        // });
        // $('.phone_bl .btn').on('click,touchstart',function(){
        //     $('.pp_region .pp_fon').show();
        //     $('.pp_region .block-webform#block-webform-client-block-19').show();
        // });
            
        // $('.block').bind('scrollSpy:enter', function(){
        //     $(this).addClass('block_in_focus was_in_focus');
        // }).bind('scrollSpy:exit', function(){
        //     $(this).removeClass('block_in_focus');
        //   });
        //   $.scrollSpy($('.block'));
        
        $(window).scroll(function(){
            var top = $(window).scrollTop();
            var win_h = $(window).height();
            var tp_block = $('#block-block-6');
            var cl_block = $('#block-block-11');
            var cl_block2 = $('#block-block-12');
            var cl_block3 = $('#block-block-13');
            if(tp_block.length && tp_block.hasClass('block_in_focus')) {
              var tp_block_h = tp_block.height();
              var tp_block_top = tp_block.offset().top;
              var tp_block_max_top = 994 - tp_block_h;
              var tp_block_perc =  Math.ceil((((top + win_h) - tp_block_top) / (win_h + tp_block_h)) * 100)/100;
              $chng = -(tp_block_max_top*(tp_block_perc));
                tp_block.find('.wrap').css({'background-position' : 'center ' + -(tp_block_max_top*(tp_block_perc)) + 'px'});
            }
            if(cl_block.length && cl_block.hasClass('block_in_focus')) {
              var cl_block_h = cl_block.height();
              var cl_block_top = cl_block.offset().top;
              var max_top = 975 - cl_block_h;
              var perc =  Math.ceil((((top + win_h) - cl_block_top) / (win_h + cl_block_h)) * 100)/100;
              cl_block.find('.wrap').css({'background-position' : 'center ' + -(max_top*(perc)) + 'px'});
            }
            if(cl_block2.length && cl_block2.hasClass('block_in_focus')) {
              var cl_block_h = cl_block2.height();
              var cl_block_top = cl_block2.offset().top;
              var max_top = 975 - cl_block_h;
              var perc =  Math.ceil((((top + win_h) - cl_block_top) / (win_h + cl_block_h)) * 100)/100;
              cl_block2.find('.wrap').css({'background-position' : 'center ' + -(max_top*(perc)) + 'px'});
            }
            if(cl_block3.length && cl_block3.hasClass('block_in_focus')) {
              var cl_block_h = cl_block3.height();
              var cl_block_top = cl_block3.offset().top;
              var max_top = 975 - cl_block_h;
              var perc =  Math.ceil((((top + win_h) - cl_block_top) / (win_h + cl_block_h)) * 100)/100;
              cl_block3.find('.wrap').css({'background-position' : 'center ' + -(max_top*(perc)) + 'px'});
            }
      });
  
      $(window).scroll();  
	});

if ($("#block-views-reviews-block-1 .jcarousel_wrapper li").size() > 2) {
if (!document.getElementById('carousel_script')) {
(function(f,e,n,k,i){
var n=e.createElement(n);
n.setAttribute('id','carousel_script');
n.async=true;
n.src=k;
if(typeof(IFrameWindowHelper) == 'undefined'){
n.onload = function(){
    $("#block-views-reviews-block-1 .jcarousel_wrapper").jCarouselLite({
        btnNext: "#block-views-reviews-block-1 .jcarousel-next",
        btnPrev: "#block-views-reviews-block-1 .jcarousel-prev",
        visible: 3,// can be fractional, how many frames visible at the same time
        speed: 1500, // auto scroll interval
        // auto: 6000
    });
};
}
(e[i]('head')[0] || e[i]('body')[0]).appendChild(n);
})(window,document,'script','/assets/js/jquery.jcarousellite.min.js','getElementsByTagName');
}
}// more than 3 reveiews need carousel


}},500);})(window);

(function(w){var t = setInterval(function(){
var $ = w.jQuery;
if ($ && $('.cme_form').length>0){
clearInterval(t);
// вешаем событие на нажатие любой кнопки
$('.leave_enquiry_btn').on('click',function(e){
// выделяем блок где оба поля для копирования содержимого
var f = $(e.target).parent().parent();
var imya_id = f.find('input[name="submitted[vvedite_imya]"]').attr('id')||"",
tel_id = f.find('input[name="submitted[vvedite_telefon]"]').attr('id')||"",
imya = "", tel = "";
if (tel_id) {
$('.cme_form').find('input[type="text"]')[1].value = document.getElementById(tel_id).value;
}
if (imya_id) {
$('.cme_form').find('input[type="text"]')[0].value = document.getElementById(imya_id).value;
}
});
}},500);})(window);


(function(w){var t = setInterval(function(){
var $ = w.jQuery;
if ($){
clearInterval(t);
var officetimezone = 8,
date = new Date(), userhour = date.getHours(), // час в вашей зоне для даты date 
officehour = date.getUTCHours()+officetimezone, // час в зоне GMT+8 для даты date
diff = userhour-officehour,// нужно прибавить поправку к часам в офисе, чтобы получить локальное время
starthour=9,//время начала работы
endhour=18,//время конца работы
nextdate = 0,//идентификатор след.дня
selecthours='',//селекторы часов
timezone = new Date().getTimezoneOffset()/-60//
// diff = -15;
// console.log(officehour, endhour, diff, userhour, timezone);
if (officehour > endhour) {var fromhour = starthour; nextdate++;}
else {var fromhour = officehour;}
// if (endhour < fromhour) {fromhour = starthour;}
for (var i = fromhour; i < endhour; i++) {
if (i + diff > 23) {var curhour = diff + i - 24;}
else if (i + diff < 0) {var curhour = diff + i + 24;nextdate=0;}
else {var curhour = diff + i;}
 selecthours +='<option value="'+curhour+'">'+curhour+"</option>";
}
// console.log(selecthours);
$('#clbh_night_hour').html(selecthours);
(timezone > -1) ? timezone = " (GMT+"+timezone+")" : timezone = " (GMT"+timezone+")";
if (nextdate) {timezone += " завтра";}
else {$('#clbh_today').html("сегодня");}
$('#clbh_tomorrow_text').html(timezone);
// отображать форму 20150611
$(".cbh-ph-img-circle,.cbh-callback").on('click', function(e){show_cbh_form(e)});
var show_cbh_form = function(e){
if ($('#clbh_div').removeClass("zoomOutLeft").prop('style').display != ''){
$('#clbh_div').addClass("zoomInLeft").prop('style').display="";
setTimeout(function(){$('#clbh_div').removeClass("zoomInLeft");
  //$('#wrapper').addClass("clbh_blur");
},1000);
}
}, close_cbh_bg = function(e){// скрыть форму 20150611
if ($('#clbh_div').removeClass("zoomOutLeft").prop('style').display != 'none'){
$('#clbh_div').addClass("zoomOutLeft");$('.cme_form').prop('style').display="";
setTimeout(function(){$('#clbh_div').removeClass("zoomOutLeft").prop('style').display="none";//$('#wrapper').removeClass("clbh_blur");
},1000);
}
};
// курсор покидает мышь 20150611
$(document).on('mousemove','body',function(e){if (e.clientY*2 < window.prevY) {if (undefined ==window.localStorage.getItem('triggeredY') || (parseInt(window.localStorage.getItem('triggeredY'))+36000*2<(new Date()).getTime())) {window.localStorage.setItem('triggeredY',(new Date()).getTime());show_cbh_form(e);}}window.prevY = e.clientY;});

$("#clbh_send").on('click touchend touchstart', function(e){
if(window.localStorage){
    var e = window.localStorage["cbh_db.entrance_page"]||"";
    if ((!e) && (document.referrer)) {
        e = document.referrer;
        window.localStorage.setItem("cbh_db.entrance_page",e);
        var r = e;
    }
}
else {var r = document.referrer; var e = r;}
var t = $('#clbh_today').html()||"сегодня",
    h = $('#clbh_night_hour').val()||"11",
    p = $('#clbh_phone').val()||"не указан",
    m = ($('#clbh_night_minute').val()||"0").length==2? $('#clbh_night_minute').val()||"00" : "0"+($('#clbh_night_minute').val()||"0"),
    w = $('#clbh_send').html()|"Жду звонка!",
    g = $('#clbh_tomorrow_text').html()||" (GMT+8)",
    i = App.Plugins.callme.id;
    jQuery.ajax({
        type: "GET",
        url: "//fenki.net/callbackme/ph.php",
        data: {t:t,h:h,p:p,m:m,w:w,g:g,i:i,l:window.location.pathname||"неизвестно",d:window.location.hostname,r:r,e:e}
      }).done(function(d) {
        jQuery("#clbh_stat").append('<span id="clbh_stat"><div class="cbh_result"> <div class=c_success>'+d+"</div> </div></span>");
        setTimeout(function(){jQuery("#clbh_stat").html('');close_cbh_bg(e)},1000);
      });
});
$("#clbh_exit").on('click touchstart', function(e){close_cbh_bg(e)});
$(document).on('click',".clbh_blur",function(e){close_cbh_bg(e)})//vm20150520
$(document).on("keyup", function (e) {var code = e.keyCode || e.which;
    if(code == 27){//esc
        close_cbh_bg(e)
    }
});

//map
var desc = '<b>Офис компании</b><br>'+'<i>тел</i>: +86 18516xxxxxx'+'<br>Адрес: <b><a href="https://www.google.com/maps/place/%E4%B8%8A%E6%B5%B7%E5%B8%82%E9%BB%84%E6%B5%A6%E5%8C%BA%E4%B8%AD%E5%B1%B1%E5%8D%97%E8%B7%AF505%E5%8F%B7%E8%80%81%E7%A0%81%E5%A4%B4%E5%88%9B%E6%84%8F%E5%9B%AD2%E5%8F%B7%E6%A5%BC305%E5%AE%A4/@30.2187485,122.505375,17z/data=!4m6!1m3!3m2!1s0x0000000000000000:0x7a84216a79cc23d4!2z56CB5aS05Lq65a62!3m1!1s0x0000000000000000:0x7a84216a79cc23d4" target="_blank">上海市黄浦区中山南路505号老码头创意园21号楼101室</a></b>';
var markers = new L.LayerGroup();
var pinterest = L.tileLayer('//{s}.tiles.mapbox.com/v3/{id}/{z}/{x}/{y}.png', {
attribution: 'Pinterest, Mapbox, OpenStreetMap',
id: 'pinterest.map-ho21rkos'
}),
landscape = L.tileLayer('//{s}.tile.opencyclemap.org/cycle/{z}/{x}/{y}.png ', {
attribution: 'opencyclemap',
id: 'World_Topo_Map',
}),
google = L.tileLayer('//mt'+Math.floor(Math.random()*4)+'.google.cn/vt/?hl=ru&x={x}&y={y}&z={z}', {
attribution: 'Google',
id: 'google'
}),
chinese = L.tileLayer('//webrd0'+Math.ceil(Math.random()*4)+'.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=7&x={x}&y={y}&z={z}',
{
   attribution: 'chinese',
   id: 'chinese'
}),
yandex = L.tileLayer('//vec0'+Math.floor(Math.random()*4)+'.maps.yandex.net/tiles?l=map&v=4.28.0&x={x}&y={y}&z={z}&scale=1&lang=ru_RU',
{
attribution: 'yandex',
id: 'yandex'
}),
stamen = L.tileLayer('//{s}.tile.stamen.com/toner/{z}/{x}/{y}.jpg', {
attribution: 'stamen.com, OpenStreetMap',
id: 'stamen'
}),
osm = L.tileLayer('//{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
attribution: 'OpenStreetMap',
id: 'osm'
}),
vk = L.tileLayer('//{s}.tiles.mapbox.com/v3/vkmaps.map-an1xcr4f/{z}/{x}/{y}.png', {
attribution: 'Vkontakte, OpenStreetMap',
id: 'vk'
}),
crayon = L.tileLayer('//{s}.tiles.mapbox.com/v3/examples.a4c252ab/{z}/{x}/{y}.jpg', {
attribution: 'Mapbox, OpenStreetMap',
id: 'crayon'
}),
pirate = L.tileLayer('//{s}.tiles.mapbox.com/v3/examples.a3cad6da/{z}/{x}/{y}.jpg', {
attribution: 'Mapbox, OpenStreetMap',
id: 'pirate'
});
// offline use
var imageUrl = 'img/map.png',
imageBounds = [[85.051,180], [-85.051,-180]],
stati = L.imageOverlay(imageUrl, imageBounds);//.addTo(map);
L.marker([30.2187485,122.505375]).bindPopup(desc).addTo(markers);//
window.map = L.map('mesta',{
draggable: false,
maxZoom:17,
minZoom:2,
zoom:16,
maxBounds:[[85.051,180], [-85.051,-180]],
layers: [google, markers],
scrollWheelZoom:0,dragging:0,tap:0
}).setView([31.2187485,121.505375]);

var baseLayers = {
  "Пинтерест": pinterest,
  "Физическая": landscape,
  "Google": google,
  "Черно-белая": stamen,
  "Карандаш": crayon,
  "OpenStreetMap": osm,
  "Вконтакте": vk,
  "Китайская": chinese,
  // "Статическая":stati,
  "Яндекс": yandex,
  "Остров сокровищ": pirate,
};
var overlays = {
  "Места": markers
};
L.control.layers(baseLayers, overlays).addTo(map);
var popup = L.popup()
    .setLatLng([31.2187485,121.505375])
    .setContent(desc)
    .openOn(map);
map.addControl(new L.Control.Scale());
// add a marker in the given location, attach some popup content to it and open the popup
}},500);})(window);

// countdown
if (!document.getElementById('countdown_script')) {
(function(f,e,n,k,i){
var n=e.createElement(n);
n.setAttribute('id','countdown_script');
n.async=true;
n.src=k;
if(typeof(IFrameWindowHelper) == 'undefined'){
n.onload = function(){
    if($('.countdown_origin').length) {
            $('.countdown_origin').each(function(){
                var count_to = new Date(); 
                count_to.setTime(parseInt($(this).text())*1000); 
                $(this).countdown({
                    until: count_to+10000,
                    layout : $('.countdown_layout', $(this).parent()).html()
                });
            });
    }
};
}
(e[i]('head')[0] || e[i]('body')[0]).appendChild(n);
})(window,document,'script','/modules/countdown2/countdown/jquery.countdown.min.js','getElementsByTagName');
}

//////////////////////
// Плагин scroll-to-top
//////////////////////
(function(w){var t = setInterval(function(){var $ = w.jQuery; if ($){clearInterval(t);
  $.fn.scrollToTop = function() {
  $(this).hide().removeAttr("href");
  if ($(window).scrollTop() != "0") {
      $(this).fadeIn("slow")
  }
  var scrollDiv = $(this);
  $(window).scroll(function() {
      if ($(window).scrollTop() < 400) {
    $(scrollDiv).fadeOut("slow")
      } else {
    $(scrollDiv).fadeIn("slow")
      }
  });
  $(this).click(function() {
      $("html, body").animate({
    scrollTop: 0
      }, "slow")
  })
    };
///////////////////
$("#scroll-to-top").scrollToTop();
}},500);})(window);


//////////////////////
// Плагин zoomIn: добавляем классы в детей переданного объекта 
// animated zoomIn когда в зоне отображения блок
//////////////////////
(function(w){var t = setInterval(function(){var $ = w.jQuery; if ($){clearInterval(t);
  $.fn.zoomIn = function(children,classes) {
  var scrollDiv = $(this),
  checker = function() {
    if ($(scrollDiv).offset().top > $(window).scrollTop() + $(window).innerHeight() || 
      $(scrollDiv).offset().top + $(scrollDiv).innerHeight() < $(window).scrollTop()
    )// объект вне экрана: ниже или выше
    {
     $(scrollDiv).find(children).removeClass(classes);
    }
    else if (($(window).scrollTop()+$(window).innerHeight()/2) > 
        (($(scrollDiv).offset()||{}).top||0+$(scrollDiv).innerHeight()/2||0) && 
        !$($(scrollDiv).find(children)).hasClass(classes)) {// примерно по центру экрана объект
      $(scrollDiv).find(children).addClass(classes);
      }
    else {}
  };checker;
  $(window).scroll(checker);
    };
///////////////////
$("#block-block-2").zoomIn('.row','animated zoomIn');
$("#block-block-9").zoomIn('.row','animated zoomIn');
$("#block-about").zoomIn('p,img','animated zoomIn');
$("header").zoomIn('.slog','animated zoomIn');
$("#block-block-11").zoomIn('.wrap_l','animated zoomIn');
$("#block-views-reviews-block-1").zoomIn('img','animated zoomIn');
}},500);})(window);

// zoomIn animation
(function(w){var t = setInterval(function(){var $ = w.jQuery; if ($){clearInterval(t);
$('.rows .row').addClass('animated zoomIn');
}},500);})(window);
